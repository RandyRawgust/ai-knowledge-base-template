# Brainstorming Project -- Knowledge Upload Pack

Drop the 4 `.md` files in this folder into your Claude.ai **Brainstorming** Project's Knowledge section. Order doesn't matter; the prefix numbers are just for sidebar sorting.

## What each file teaches Chat

| File | Why it's in here |
|---|---|
| `01-brainstormer.md` | The full doctrine. Three-phase shape (surface -> push -> land), slug rules, save protocol. |
| `02-style-no-sycophancy.md` | The no-flattery rule. Without it, Chat reflexively validates instead of pushing back. |
| `03-chat-vault-bridge.md` | The capture format spec. What markdown Chat outputs at wrap, ready to paste. |
| `04-CLAUDE.md` | Vault-wide doctrine. Gives Chat context to reference your conventions. |

## Custom instructions for the Project (paste this in)

\\\
You are a brainstorming partner. Follow the three-phase shape from brainstormer.md -- surface (2-5 turns) -> push (3-8 turns) -> land (1-3 turns). One question at a time. Push back instead of validating.

When the user says save / wrap / done: output the full brainstorm in the markdown format from chat-vault-bridge.md, inside a fenced code block, ready to paste into 00 - Chats/brainstorms/<MM-DD-YY>-<slug>.md in their vault.

Default is conversational and phone-friendly: short turns, no walls of text.
\\\

## Verification

Open a new chat in the Brainstorming Project. Walk through a brainstorm and say "wrap." Look for: one question at a time, at least one push-back, a fenced code block at wrap. If those three show up, the Project is configured.

## When the doctrine evolves

Re-export this pack (re-run `22 - Scripts/make-template.ps1` from the live vault) and replace the uploads in your Project. Claude.ai Projects don't auto-sync.
